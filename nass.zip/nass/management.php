       <!-- ======= Management Section ======= -->
       <section id="team" class="team section-bg">
        <div class="container" data-aos="fade-up">
          <div class="section-title">
            <h2>Management</h2>
            <p>
              Management of National Assembly Service Commission
            </p>
          </div>

          <div class="row">
            <div class="col-lg-12 mt-4 mb-2 mt-lg-0">
              <div
                class="member d-flex align-items-start"
                data-aos="zoom-in"
                data-aos-delay="100"
              >
                <div class="pic">
                  <img
                    src="assets/img/sec.png"
                    class="img-fluid"
                    alt=""
                  />
                </div>
                <div class="member-info">

                  <a href='chairman.php'><h4>Eng. Ahmed Kadi Amshi</h4></a>
                  <a href='chairman.php'><span>Executive Chairman</span></a>
                  <a href='chairman.php'><p>
                  Ahmed Kadi Amshi (born 9 May 1954) is a renowned Engineer, Technocrat ....Read More
                  </p></a>
                  <div class="social">
                  <a href=""><i class="bx bxl-twitter" ></i></a>
                    <a href=""><i class="bx bxl-facebook"></i></a>
                    <a href=""><i class="bx bxl-instagram"></i></a>
                    <a href=""><i class="bx bxl-linkedin"></i> </a>
                  </div>
                </div>
              </div>
            </div>
     
            <div class="col-lg-12 mt-4 mt-lg-0">
              <div
                class="member d-flex align-items-start"
                data-aos="zoom-in"
                data-aos-delay="200"
              >
                <div class="pic">
                  <img src="assets/img/olabode.png" class="img-fluid" alt="" />
                </div>
                <div class="member-info">
                <a href='chairman.php'><h4>Hon. Hakeem Olabode Akamo</h4></a>
                  <a href='chairman.php'><span>Representative South West</span></a>
                  <a href='chairman.php'><p>
                  Hon. Hakeem Olabode Akamo  was born into the family of Akamo and Onitiri in  ....Read More
                  </p></a>
                  <div class="social">
                  <a href=""><i class="bx bxl-twitter" ></i></a>
                    <a href=""><i class="bx bxl-facebook"></i></a>
                    <a href=""><i class="bx bxl-instagram"></i></a>
                    <a href=""><i class="bx bxl-linkedin"></i> </a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-6 mt-4">
              <div
                class="member d-flex align-items-start"
                data-aos="zoom-in"
                data-aos-delay="300"
              >
                <div class="pic">
                  <img src="assets/img/babagana.png" class="img-fluid" alt="" />
                </div>
                <div class="member-info">
                <a href='chairman.php'><h4>Hon. BABAGANA MODU </h4></a>
                  <a href='chairman.php'><span>North East Representative</span></a>
                  <a href='chairman.php'><p>
                  Hon. BABAGANA MODU was born on 31st December, 1951 in Bama, Bama Local   ....Read More
                  </p></a>
                  <div class="social">
                  <a href=""><i class="bx bxl-twitter" ></i></a>
                    <a href=""><i class="bx bxl-facebook"></i></a>
                    <a href=""><i class="bx bxl-instagram"></i></a>
                    <a href=""><i class="bx bxl-linkedin"></i> </a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6 mt-4">
              <div
                class="member d-flex align-items-start"
                data-aos="zoom-in"
                data-aos-delay="300"
              >
                <div class="pic">
                  <img src="assets/img/shinkafi.png" class="img-fluid" alt="" />
                </div>
                <div class="member-info">
                <a href='chairman.php'><h4>HON. BILYAMINU YUSUF SHINKAFI  </h4></a>
                  <a href='chairman.php'><span>North West Representative</span></a>
                  <a href='chairman.php'><p>
                  HON. BILYAMINU YUSUF SHINKAFI is a  teacher, an administrator and a politician, ...Read More...
                  </p></a>
                  <div class="social">
                  <a href=""><i class="bx bxl-twitter" ></i></a>
                    <a href=""><i class="bx bxl-facebook"></i></a>
                    <a href=""><i class="bx bxl-instagram"></i></a>
                    <a href=""><i class="bx bxl-linkedin"></i> </a>
                  </div>
                </div>
              </div>
            </div>
            <!-- <div class="col-lg-6 mt-4">
              <div
                class="member d-flex align-items-start"
                data-aos="zoom-in"
                data-aos-delay="400"
              >
              
                <div class="pic">
                  <img
                    src="assets/img/shinkafi.png"
                    class="img-fluid"
                    alt=""
                  />
                </div>
                <div class="member-info">
                  <h4>HON. BILYAMINU YUSUF SHINKAFI </h4>
                  <span>North West Representative</span>
                  <p>
                  HON. BILYAMINU YUSUF SHINKAFI is a  teacher, an administrator and a politician, Hon. Shinkafi was born...Read More...
                  </p>
                  <div class="social">
                    <a href=""><i class="bx bxl-twitter" ></i></a>
                    <a href=""><i class="bx bxl-facebook"></i></a>
                    <a href=""><i class="bx bxl-instagram"></i></a>
                    <a href=""><i class="bx bxl-linkedin"></i> </a>
                  </div>
                </div>
              </div>
            </div> -->
          </div>
        </div>
      </section>