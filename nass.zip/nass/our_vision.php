<?php

include('header.php');
include('navbar.php');

?>

<div class="container">
<h2>Mission and Vision</h2>

</div>






<?php
include('footer_10.php');
?>