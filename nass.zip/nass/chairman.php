<?php

include('header.php');
include('navbar.php');


?>



<section id="portfolio-details" class="portfolio-details">
      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-8">
            <div class="portfolio-details-slider swiper">
              <div class="swiper-wrapper align-items-center">

                <div class="swiper-slide">
                  <img src="assets/img/portfolio/portfolio-1.jpg" alt="">
                </div>

                <div class="swiper-slide">
                  <img src="assets/img/portfolio/portfolio-2.jpg" alt="">
                </div>

                <div class="swiper-slide">
                  <img src="assets/img/portfolio/portfolio-3.jpg" alt="">
                </div>

              </div>
              <div class="swiper-pagination"></div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="portfolio-info align-items-center">
            <img src="./assets/img/sec.png" class="img-thumbnail" alt="Eng. Ahmed Kadi Amshi">
              <h3>Eng. Ahmed Kadi Amshi</h3>
              
              <!-- <ul>
                <li><strong>Designation</strong>: Executive Chairman</li>
                <li><strong>National Assembly Service Commission</strong></li> -->
                <!-- <li><strong>Project date</strong>: 01 March, 2020</li>
                <li><strong>Project URL</strong>: <a href="#">www.example.com</a></li> -->
              <!-- </ul>
            </div> -->
            <div class="portfolio-description">
              <p>
              Eng. Ahmed Kadi Amshi (born 9 May 1954) is a renowned Engineer, 
              Technocrat and an astute Administrator in Nigeria, 
              who serves as the Executive Chairman of National Assembly Service Commission (NASC). <br><br>
              He was inaugurated as the Executive Chairman of NASC on the 26th of February 2020 by His Excellency, 
              Muhammadu Buhari, President of the Federal Republic of Nigeria. 
            Ahmed Kadi Amshi is a Fellow of the Nigerian Society of Engineers as well as a Fellow of the Nigerian Institution of Mechanical Engineers. 
            He has numerous laurels to his name, both academic and professional. 
              </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-















<?php

include('footer_10.php');









?>