  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center" style="background-color: green">
    <div class="container d-flex justify-content-between">

      <div class="logo">
        <h1 class="text-light"><a href="index.php"></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <a href="index.php"><img src="assets/img/coatofarms.svg" alt="" class="img-fluid"></a>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li ><a class="active" href="index.php" style="color: #fff; background-color: green; font-weight: bold">Home</a></li>
          <!-- <li><a href="about.php" style="color: #fff; background-color: green; font-weight: bold">About</a></li> -->
          <li><a href="faq.php" style="color: #fff; background-color: green; font-weight: bold">FAQ</a></li>
          <li><a href="https://www.nass.gov.ng/" style="color: #fff; background-color: green; font-weight: bold">National Assembly</a></li>
          <li><a href="#" style="color: #fff; background-color: green; font-weight: bold">News and Events</a></li>
          <li><a href="contact_us.php" style="color: #fff; background-color: green; font-weight: bold">Contact Us</a></li>

          <li class="dropdown"><a href="#" style="color: #fff; background-color: green; font-weight: bold"><span>About Us</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
        
                        <li><a href="our_strategy.php">Our Strategy</a></li>
                        <li><a href="our_vision.php">Mission and Vision</a></li>
  
                    
            </ul>

   
          <li class="dropdown"><a href="#" style="color: #fff; background-color: green; font-weight: bold"><span>Management</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <!-- <li><a href="#">About Us</a></li> -->
              <li class="dropdown"><a href="#"><span>Management Staff</span> <i class="bi bi-chevron-right"></i></a>
              <ul>
                  <li><a href="#">Head of Units</a></li>
                  <li><a href="#">Head of Divisions</a></li>
                  <!-- <li><a href="#">Deep Drop Down 3</a></li> -->
            
                </ul>
              </li>
              <li class="dropdown"><a href="#"><span>Commissioners</span> <i class="bi bi-chevron-right"></i></a>
              
                <ul>
                  <li><a href="chairman.php">Executive Chairman</a></li>
                  <li><a href="#">Commissioner North Central</a></li>
                  <li><a href="#">Commissioner South South</a></li>
                  <li><a href="#">Commissioner North East</a></li>
                  <li><a href="#">Commissioner South West</a></li>
                  <li><a href="#">Commissioner North West</a></li>
                  <li><a href="#">Commissioner South East</a></li>
                </ul>
                <!-- <li class="dropdown"><a href="#"><span>Deep Drop Down 2</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li> -->
              <!-- <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li> -->
            </ul>

            <li class="dropdown"><a href="#" style="color: #fff; background-color: green; font-weight: bold"><span>Vacancies</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
        
                        <li><a href="register.php">Apply</a></li>
                        <li><a href="login.php">Staff Login</a></li>
  
                    
            </ul>
          </li>

          

        
        
        </ul>
        <i class="bi bi-list mobile-nav-toggle" style="color: white; background-color: green"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
