<?php

include('header.php');
include('navbar.php');


?>

<div class="container map-section mt-3">
   <div class="section-title">
            <h2>Our Strategy</h2>
          </div>

      <div class="container">

        <div class="row justify-content-center" data-aos="fade-up">

          <div class="col-lg-10 mb-5">
          <h5 class="mb-2">The vision and mission of the Commission will be achieved through the following strategies </h5>

            i.   Holding statutory meetings of the Commission <br>
            ii.  Application of the Committee system for in-depth deliberations  of the Commission’s work. <br>
            iii. Holding regular consultations with its counterparts in the Federal Civil Service Commission, the Judicial Service Commission and other scheduled Service Commission.<br>
            iv.  Adherence to the Federal Character Principle in the appointment of officials at all levels. <br>
            v.   Encourage the pursuit of  regular training and re-training of staff of the National Assembly Service. <br>
            vi.  Enforcement of discipline in the National Assembly Service by ensuring an appropriate punishment and reward system, thus providing efficiency and productivity.<br>

        

          </div>

        </div>

  

      </div>



    </div>






<?php

include('footer_10.php');









?>