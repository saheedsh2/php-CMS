<?php

include('header.php');
include('navbar.php');

include('carousel.php');


// include('services_6.php');



include('management.php');
include('contact_9.php');
include('footer_10.php');









?>